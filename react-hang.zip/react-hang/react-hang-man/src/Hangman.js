// Importing necessary React hooks, styles, and the GetHelp component
import React, { useState, useEffect } from 'react';
import './Hangman.css';
import GetHelp from './GetHelp';
import wordFile from "./dictionary.txt"; // Importing the dictionary file

// Importing hangman images for different states
import state1 from './state1.GIF';
import state2 from './state2.GIF';
import state3 from './state3.GIF';
import state4 from './state4.GIF';
import state5 from './state5.GIF';
import state6 from './state6.GIF';
import state7 from './state7.GIF';
import state8 from './state8.GIF';
import state9 from './state9.GIF';
import state10 from './state10.gif';
import state11 from './state11.GIF';

// Array to hold the hangman images for different steps
const hangmanSteps = [
  state1, state2, state3, state4, state5, state6, state7, state8, state9, state10, state11
];

// Main Hangman component
function Hangman() {
  // State variables to manage the game state
  const [word, setWord] = useState('');
  const [guessedLetters, setGuessedLetters] = useState(new Set());
  const [wrongGuesses, setWrongGuesses] = useState(0);
  const [message, setMessage] = useState('');
  const [showHelp, setShowHelp] = useState(false);

  // Effect to fetch a random word when the component mounts or the word changes
  useEffect(() => {
    if (word === '') {
      fetchRandomWord(setWord);
    }
  }, [word]);

  // Function to handle letter guessing
  function guessLetter(letter) {
    const upperCaseLetter = letter.toUpperCase();
    setGuessedLetters((prev) => new Set([...prev, upperCaseLetter]));
    const wordUpperCase = word.toUpperCase();

    if (!wordUpperCase.includes(upperCaseLetter)) {
      setWrongGuesses((prev) => prev + 1);
    }
  }

  // Function to restart the game
  function restartGame() {
    fetchRandomWord(setWord);
    setGuessedLetters(new Set());
    setWrongGuesses(0);
    setMessage('');
  }

  // Display the current state of the word
  const wordDisplay = word
    .split('')
    .map((letter) => (letter === ' ' || guessedLetters.has(letter.toUpperCase()) ? letter : '_'));
  const gameWon = wordDisplay.every((letter) => letter !== '_');
  const gameLost = wrongGuesses >= hangmanSteps.length - 1;

  // Render the hangman game components
  return (
    <div className='hangman-container'>
      <img src={hangmanSteps[wrongGuesses]} alt="Hangman" />
      <p>{wordDisplay.join(' ')}</p>
      <div>
        {/* Create buttons for each letter of the alphabet */}
        {Array.from({ length: 26 }, (_, i) => String.fromCharCode('A'.charCodeAt(0) + i)).map(
          (letter) => (
            <button
              key={letter}
              onClick={() => guessLetter(letter)}
              disabled={
                guessedLetters.has(letter.toUpperCase()) || gameLost || gameWon
              }
            >
              {letter}
            </button>
          )
        )}
      </div>
      {/* Add a button to trigger the help modal */}
      <button onClick={() => setShowHelp(true)}>Get Help</button>

      {/* Conditionally render the GetHelp component */}
      {showHelp && <GetHelp onClose={() => setShowHelp(false)} />}

      <p>{message}</p>
      {gameWon && <p>You won!</p>}
      {gameLost && <p>You lost!</p>}
      <button onClick={restartGame}>Restart</button>
    </div>
  );
}

// Function to fetch a random word from a dictionary file
async function fetchRandomWord(setWordCallback) {
  try {
    const response = await fetch(wordFile); // Fetching wordFile instead of "dictionary.txt"
    const words = await response.text();

    const wordArray = words.split(/\s+/).filter((word) => word.trim() !== '');

    const randomWord = wordArray[Math.floor(Math.random() * wordArray.length)].toLowerCase();

    setWordCallback(randomWord);
  } catch (error) {
    console.error('Error fetching random word:', error);
  }
}

export default Hangman;
