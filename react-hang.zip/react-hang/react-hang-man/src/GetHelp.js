import React from 'react';

const GetHelp = ({ onClose }) => {
  return (
    <div className="help-modal">
      <div className="help-content">
        <h2>Hangman Rules</h2>
        <p>
          Hangman is a word-guessing game. The goal is to guess the hidden word by suggesting letters.
        </p>
        <p>
          You can make a guess by clicking on the letter buttons provided. If the guessed letter is correct,
          it will be revealed in the word; otherwise, it will count as a wrong guess.
        </p>
        <p>
          Be careful! If you make too many wrong guesses, the hangman will be hanged, and you'll lose the game.
        </p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default GetHelp;
