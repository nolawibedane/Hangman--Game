import React from 'react';
import Hangman from './Hangman';

// Import createRoot from 'react-dom/client'
import { createRoot } from 'react-dom/client';

// Create a root using createRoot
const root = createRoot(document.getElementById('root'));

// Render your app using the created root
root.render(
  <React.StrictMode>
    <Hangman />
  </React.StrictMode>
);

