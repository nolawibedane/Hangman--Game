import React from 'react';
import Hangman from './Hangman';

function App() {
  return (
    <div className="App">
      <h1>Hangman Game</h1>
      <Hangman />
    </div>
  );
}

export default App;
